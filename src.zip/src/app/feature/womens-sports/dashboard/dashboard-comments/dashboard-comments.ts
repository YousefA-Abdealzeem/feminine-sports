import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, of } from 'rxjs';
import { PostsService } from 'app/core/services/posts';
import { UsersService } from 'app/core/services/users';
import { API_BASE } from 'app/core/services/api';

@Component({
  selector: 'app-dashboard-comments',
  imports: [CommonModule],
  templateUrl: './dashboard-comments.html',
  styleUrl: './dashboard-comments.css',
})
export class DashboardComments implements OnInit {

  serverFlagged: any[] = [];
  loading = true;

  constructor(
    public postsService: PostsService,
    public usersService: UsersService,
    private http: HttpClient
  ) {}

  private get headers(): HttpHeaders {
    const token = localStorage.getItem('token') || '';
    return new HttpHeaders({
      'ngrok-skip-browser-warning': 'true',
      Authorization: `Bearer ${token}`
    });
  }

  ngOnInit(): void {
    this.http.get<any[]>(`${API_BASE}/Admin/hate-speech`, { headers: this.headers })
      .pipe(catchError(() => of([])))
      .subscribe(data => {
        this.serverFlagged = data || [];
        this.loading = false;
      });
  }

  // 👇 عشان template يستخدم flagged مباشرة
  get flagged(): any[] {
    return this.allFlagged;
  }

  get allFlagged(): any[] {
    const local = this.postsService.flaggedComments || [];
    const serverIds = new Set(this.serverFlagged.map(c => c.id));
    const localOnly = local.filter(c => !serverIds.has(c.id));
    return [...this.serverFlagged, ...localOnly];
  }

  highlight(text: string): string {
    if (!text) return '';
    return text
      .replace(/(bad|hate|abuse)/gi, '<mark>$1</mark>');
  }

  getUserStatus(uid: number): string {
    return this.usersService.getUserById(uid)?.status ?? 'active';
  }

  getStatusLabel(uid: number): string {
    const s = this.getUserStatus(uid);
    return s === 'active' ? 'نشط' : s === 'suspended' ? 'موقف' : 'محظور';
  }

  getUserViolations(uid: number): number {
    return this.usersService.getUserById(uid)?.violations ?? 0;
  }

  deleteComment(postId: number, commentId: number): void {
    this.postsService.deleteComment(postId, commentId);
    this.serverFlagged = this.serverFlagged.filter(c => c.id !== commentId);
  }

  suspendUser(uid: number, days: number = 3): void {
    this.usersService.suspend(uid, days);
  }

  banUser(uid: number): void {
    this.usersService.ban(uid);
  }

  unbanUser(uid: number): void {
    this.usersService.unban(uid);
  }

  // 👇 دي اللي ناقصة في الـ HTML
  activateUser(uid: number): void {
    this.usersService.unban(uid);
  }
}